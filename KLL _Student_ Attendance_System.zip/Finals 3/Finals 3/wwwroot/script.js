﻿const subjectSelect = document.getElementById("subjectSelect");
const attendanceDate = document.getElementById("attendanceDate");
const attendanceBody = document.getElementById("attendanceBody");
const saveBtn = document.getElementById("saveAttendance");
const attendanceRecordsContainer = document.getElementById("attendanceRecordsContainer");

attendanceDate.valueAsDate = new Date();

fetch("/api/attendance/subjects")
    .then(res => res.json())
    .then(data => {
        subjectSelect.innerHTML = "";
        data.forEach(s => {
            const option = document.createElement("option");
            option.value = s.subjectID;
            option.textContent = s.name;
            subjectSelect.appendChild(option);
        });
        if (data.length > 0) loadAttendanceRecords(data[0].subjectID);
    });

fetch("/api/attendance/students")
    .then(res => res.json())
    .then(data => {
        attendanceBody.innerHTML = "";
        data.forEach(stu => {
            const row = document.createElement("tr");
            row.dataset.studentId = stu.studentID;
            const name = document.createElement("td");
            name.textContent = stu.name;
            const grade = document.createElement("td");
            grade.textContent = stu.grade;
            const section = document.createElement("td");
            section.textContent = stu.section;
            const statusTd = document.createElement("td");
            const statusSelect = document.createElement("select");
            const present = document.createElement("option");
            present.value = "Present";
            present.textContent = "Present";
            const absent = document.createElement("option");
            absent.value = "Absent";
            absent.textContent = "Absent";
            statusSelect.appendChild(present);
            statusSelect.appendChild(absent);
            statusTd.appendChild(statusSelect);
            row.appendChild(name);
            row.appendChild(grade);
            row.appendChild(section);
            row.appendChild(statusTd);
            attendanceBody.appendChild(row);
        });
    });

function loadAttendanceRecords(subjectId) {
    fetch(`/api/attendance/allrecords?subjectID=${subjectId}`)
        .then(res => res.json())
        .then(data => {
            attendanceRecordsContainer.innerHTML = "";
            const grouped = {};
            data.forEach(r => {
                if (!grouped[r.attendanceDate]) grouped[r.attendanceDate] = [];
                grouped[r.attendanceDate].push(r);
            });
            Object.keys(grouped).sort((a, b) => new Date(b) - new Date(a)).forEach(date => {
                const dateHeader = document.createElement("h4");
                dateHeader.textContent = date;
                attendanceRecordsContainer.appendChild(dateHeader);
                const table = document.createElement("table");
                table.classList.add("miniTable");
                const thead = document.createElement("thead");
                const headRow = document.createElement("tr");
                ["Name", "Grade", "Section", "Status"].forEach(h => {
                    const th = document.createElement("th");
                    th.textContent = h;
                    headRow.appendChild(th);
                });
                thead.appendChild(headRow);
                table.appendChild(thead);
                const tbody = document.createElement("tbody");
                grouped[date].forEach(r => {
                    const row = document.createElement("tr");
                    const nameTd = document.createElement("td");
                    nameTd.textContent = r.name;
                    const gradeTd = document.createElement("td");
                    gradeTd.textContent = r.grade;
                    const sectionTd = document.createElement("td");
                    sectionTd.textContent = r.section;
                    const statusTd = document.createElement("td");
                    statusTd.textContent = r.status;
                    row.appendChild(nameTd);
                    row.appendChild(gradeTd);
                    row.appendChild(sectionTd);
                    row.appendChild(statusTd);
                    tbody.appendChild(row);
                });
                table.appendChild(tbody);
                attendanceRecordsContainer.appendChild(table);
            });
        });
}

saveBtn.addEventListener("click", () => {
    const subjectId = subjectSelect.value;
    const date = attendanceDate.value;
    const records = [];
    document.querySelectorAll("#attendanceBody tr").forEach(row => {
        const studentId = row.dataset.studentId;
        const status = row.querySelector("select").value;
        records.push({
            studentID: parseInt(studentId),
            subjectID: parseInt(subjectId),
            attendanceDate: date,
            status: status
        });
    });
    fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(records)
    }).then(() => loadAttendanceRecords(subjectId));
});

subjectSelect.addEventListener("change", () => {
    const subjectId = subjectSelect.value;
    loadAttendanceRecords(subjectId);
});
