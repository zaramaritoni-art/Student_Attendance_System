﻿namespace Finals_3.Models
{
    public class Student
    {
        public int StudentID { get; set; }
        public string Name { get; set; }
        public string Grade { get; set; }
        public string Section { get; set; }
    }

    public class Subject
    {
        public int SubjectID { get; set; }
        public string Name { get; set; }
        public string Teacher { get; set; }
    }

    public class Attendance
    {
        public int AttendanceID { get; set; }
        public int StudentID { get; set; }
        public int SubjectID { get; set; }
        public DateTime AttendanceDate { get; set; }
        public string Status { get; set; }
    }
}
