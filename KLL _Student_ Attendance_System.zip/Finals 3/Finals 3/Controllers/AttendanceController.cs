﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Finals_3.Data;
using Finals_3.Models;
using System.Collections.Generic;

namespace Finals_3.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AttendanceController : ControllerBase
    {
        private readonly Db _db = new Db();

        [HttpGet("students")]
        public IActionResult GetStudents()
        {
            var students = new List<Student>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT * FROM Students", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                students.Add(new Student
                {
                    StudentID = reader.GetInt32("StudentID"),
                    Name = reader.GetString("Name"),
                    Grade = reader.GetString("Grade"),
                    Section = reader.GetString("Section")
                });
            }
            return Ok(students);
        }

        [HttpGet("subjects")]
        public IActionResult GetSubjects()
        {
            var subjects = new List<Subject>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT * FROM Subjects", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                subjects.Add(new Subject
                {
                    SubjectID = reader.GetInt32("SubjectID"),
                    Name = reader.GetString("Name"),
                    Teacher = reader.GetString("Teacher")
                });
            }
            return Ok(subjects);
        }

        [HttpPost]
        public IActionResult SaveAttendance([FromBody] List<Attendance> records)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            foreach (var a in records)
            {
                using var check = new MySqlCommand("SELECT COUNT(*) FROM Attendance WHERE StudentID=@sid AND SubjectID=@subid AND AttendanceDate=@date", conn);
                check.Parameters.AddWithValue("@sid", a.StudentID);
                check.Parameters.AddWithValue("@subid", a.SubjectID);
                check.Parameters.AddWithValue("@date", a.AttendanceDate.ToString("yyyy-MM-dd"));
                var exists = Convert.ToInt32(check.ExecuteScalar());
                if (exists == 0)
                {
                    using var cmd = new MySqlCommand("INSERT INTO Attendance (StudentID, SubjectID, AttendanceDate, Status) VALUES (@studentID, @subjectID, @date, @status)", conn);
                    cmd.Parameters.AddWithValue("@studentID", a.StudentID);
                    cmd.Parameters.AddWithValue("@subjectID", a.SubjectID);
                    cmd.Parameters.AddWithValue("@date", a.AttendanceDate.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@status", a.Status);
                    cmd.ExecuteNonQuery();
                }
            }
            return Ok();
        }

        [HttpGet("allrecords")]
        public IActionResult GetAllAttendanceRecords(int subjectID)
        {
            var list = new List<dynamic>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand(
                @"SELECT s.Name, s.Grade, s.Section, a.Status, a.AttendanceDate
                  FROM Attendance a
                  JOIN Students s ON a.StudentID = s.StudentID
                  WHERE a.SubjectID=@subid
                  ORDER BY a.AttendanceDate DESC", conn
            );
            cmd.Parameters.AddWithValue("@subid", subjectID);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new
                {
                    name = reader.GetString("Name"),
                    grade = reader.GetString("Grade"),
                    section = reader.GetString("Section"),
                    status = reader.GetString("Status"),
                    attendanceDate = reader.GetDateTime("AttendanceDate").ToString("yyyy-MM-dd")
                });
            }
            return Ok(list);
        }
    }
}
